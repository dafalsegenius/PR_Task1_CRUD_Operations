import React from 'react';

export default function NotFound(): React.ReactElement {
  return <div data-testid="notFoundContainer">Page Not Found</div>;
}
