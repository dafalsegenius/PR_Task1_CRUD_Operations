import * as React from 'react';

const Dashboard: React.FC = () => <div></div>;

export default Dashboard;
