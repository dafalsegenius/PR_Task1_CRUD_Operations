import React, { useState, useEffect } from "react";
import axios from "axios";
import CommentForm from "../components/comments/CommentForm";
import CommentList from "../components/comments/CommentList";

const CommentsPage: React.FC = () => {
  const [comments, setComments] = useState<any[]>([]);
  const [taskId] = useState<number>(1); // Removed unused setter 'setTaskId'

  const fetchComments = async () => {
    try {
      const res = await axios.get(`/api/comments/task/${taskId}`);
      setComments(res.data.data || []);
    } catch (error) {
      console.error("Error fetching comments:", error);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [taskId]);

  const addComment = async (content: string) => {
    try {
      await axios.post(`/api/comments/`, { task_id: taskId, content });
      fetchComments();
    } catch (error) {
      console.error("Error adding comment:", error);
    }
  };

  const updateComment = async (id: number, newContent: string) => {
    try {
      await axios.put(`/api/comments/comment/${id}`, { content: newContent });
      fetchComments();
    } catch (error) {
      console.error("Error updating comment:", error);
    }
  };

  const deleteComment = async (id: number) => {
    try {
      await axios.delete(`/api/comments/comment/${id}`);
      fetchComments();
    } catch (error) {
      console.error("Error deleting comment:", error);
    }
  };

  return (
    <div style={{ margin: "40px" }}>
      <h2>Task {taskId} Comments</h2>
      <CommentForm onSubmit={addComment} />
      <CommentList
        comments={comments}
        onUpdate={updateComment}
        onDelete={deleteComment}
      />
    </div>
  );
};

export default CommentsPage;
