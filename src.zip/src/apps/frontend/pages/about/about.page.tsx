import React from 'react';

export default function About(): React.ReactElement {
  return (
    <div>
      <img id="companyLogo" src="/assets/img/logo.jpg" />
    </div>
  );
}
