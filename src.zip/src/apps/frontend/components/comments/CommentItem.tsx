import React, { useState } from "react";

interface Comment {
  id: number;
  content: string;
  updated_at: string;
}

interface Props {
  comment: Comment;
  onUpdate: (id: number, newContent: string) => void;
  onDelete: (id: number) => void;
}

const CommentItem: React.FC<Props> = ({ comment, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [newContent, setNewContent] = useState(comment.content);

  const handleUpdate = () => {
    if (newContent.trim()) {
      onUpdate(comment.id, newContent);
      setIsEditing(false);
    }
  };

  return (
    <div
      style={{
        border: "1px solid #ddd",
        borderRadius: "6px",
        padding: "10px",
        marginBottom: "8px",
      }}
    >
      {isEditing ? (
        <>
          <input
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            style={{ width: "70%", padding: "5px" }}
          />
          <button onClick={handleUpdate}>💾 Save</button>
        </>
      ) : (
        <>
          <p>
            <strong>#{comment.id}</strong> {comment.content}
          </p>
          <small>{new Date(comment.updated_at).toLocaleString()}</small>
          <div style={{ marginTop: "5px" }}>
            <button onClick={() => setIsEditing(true)}>✏️ Edit</button>
            <button
              onClick={() => onDelete(comment.id)}
              style={{ marginLeft: "10px" }}
            >
              ❌ Delete
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CommentItem;
