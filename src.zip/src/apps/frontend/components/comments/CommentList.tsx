import React from "react";
import CommentItem from "./CommentItem";

interface Comment {
  id: number;
  content: string;
  updated_at: string;
}

interface Props {
  comments: Comment[];
  onUpdate: (id: number, newContent: string) => void;
  onDelete: (id: number) => void;
}

const CommentList: React.FC<Props> = ({ comments, onUpdate, onDelete }) => {
  return (
    <div>
      {comments.length === 0 ? (
        <p>No comments yet. Add one!</p>
      ) : (
        comments.map((c) => (
          <CommentItem
            key={c.id}
            comment={c}
            onUpdate={onUpdate}
            onDelete={onDelete}
          />
        ))
      )}
    </div>
  );
};

export default CommentList;
