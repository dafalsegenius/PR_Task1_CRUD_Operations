import { AxiosInstance } from "axios";
import AppService from "frontend/services/app.service";

export default class APIService extends AppService {
  apiClient: AxiosInstance;
  apiUrl: string;

  constructor() {
    super();
    this.apiUrl = "http://127.0.0.1:5000/api";

    this.apiClient = APIService.getAxiosInstance({
      baseURL: this.apiUrl,
      withCredentials: false,
    });
  }
}
