// src/apps/frontend/services/comments.service.ts
import APIService from "./api.service";

class CommentsService extends APIService {
  constructor() {
    super();
  }

  // ✅ Fetch all comments for a given task
  async getAll(taskId: number) {
    return this.apiClient.get(`/comments/${taskId}`);
  }

  // ✅ Fetch a single comment by ID
  async getById(commentId: number) {
    return this.apiClient.get(`/comments/comment/${commentId}`);
  }

  // ✅ Create a new comment
  async create(taskId: number, content: string) {
    return this.apiClient.post(`/comments/`, {
      task_id: taskId,
      content,
    });
  }

  // ✅ Update an existing comment
  async update(commentId: number, content: string) {
    return this.apiClient.put(`/comments/comment/${commentId}`, {
      content,
    });
  }

  // ✅ Delete a comment
  async delete(commentId: number) {
    return this.apiClient.delete(`/comments/comment/${commentId}`);
  }
}

export default new CommentsService();
