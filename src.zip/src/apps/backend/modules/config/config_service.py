from typing import Generic, Optional, cast
import os

from modules.config.errors import MissingKeyError
from modules.config.internals.config_manager import ConfigManager
from modules.config.types import ConfigType, ErrorCode


class ConfigService(Generic[ConfigType]):
    config_manager: ConfigManager = ConfigManager()

    if os.getenv("APP_ENV") == "test":
        try:
            config_manager.load_yaml("config/config_test.yaml")
            print("[CONFIG] Loaded test config: config/config_test.yaml")
        except Exception as e:
            print(f"[CONFIG] Warning: Could not load test config file: {e}")

    @classmethod
    def get_value(cls, key: str, default: Optional[ConfigType] = None) -> ConfigType:
        value: Optional[ConfigType] = cls.config_manager.get(key, default=default)
        if value is None:
            raise MissingKeyError(missing_key=key, error_code=ErrorCode.MISSING_KEY)
        return cast(ConfigType, value)

    @classmethod
    def has_value(cls, key: str) -> bool:
        return cls.config_manager.has(key)
