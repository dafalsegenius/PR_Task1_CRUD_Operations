import unittest
from flask import Flask
from mongomock import MongoClient
from modules.comments.routes import comments_bp


class CommentsTestCase(unittest.TestCase):
    def setUp(self):
        """Setup isolated app context + in-memory DB for each test."""
        self.app = Flask(__name__)

        # 🚀 Attach in-memory Mongo collection
        client = MongoClient()
        db = client["test_db"]
        self.app.extensions["comments_collection"] = db["comments"]

        # Register routes AFTER attaching DB
        self.app.register_blueprint(comments_bp)

        self.client = self.app.test_client()

    def test_create_and_get_comment(self):
        res = self.client.post("/api/comments/", json={"task_id": 10, "content": "First comment"})
        self.assertEqual(res.status_code, 201)
        cid = res.get_json()["data"]["id"]

        res2 = self.client.get(f"/api/comments/comment/{cid}")
        self.assertEqual(res2.status_code, 200)
        self.assertIn("First comment", res2.get_data(as_text=True))

    def test_update_comment(self):
        res = self.client.post("/api/comments/", json={"task_id": 11, "content": "Old"})
        cid = res.get_json()["data"]["id"]

        res2 = self.client.put(f"/api/comments/comment/{cid}", json={"content": "Updated text"})
        self.assertEqual(res2.status_code, 200)
        self.assertIn("Updated text", res2.get_data(as_text=True))

    def test_delete_comment(self):
        res = self.client.post("/api/comments/", json={"task_id": 12, "content": "To delete"})
        cid = res.get_json()["data"]["id"]

        res2 = self.client.delete(f"/api/comments/comment/{cid}")
        self.assertEqual(res2.status_code, 200)

    def test_missing_fields(self):
        res = self.client.post("/api/comments/", json={"task_id": 1})
        self.assertEqual(res.status_code, 400)

        res2 = self.client.put("/api/comments/comment/1", json={})
        self.assertEqual(res2.status_code, 400)


if __name__ == "__main__":
    unittest.main(verbosity=2)
