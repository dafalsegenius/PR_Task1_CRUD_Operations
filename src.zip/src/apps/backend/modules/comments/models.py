from datetime import datetime
from bson.objectid import ObjectId
from flask import current_app
from typing import Dict, Optional, List


def create_comment(task_id: int, content: str) -> Dict:
    """Insert new comment into MongoDB."""
    collection = current_app.extensions["comments_collection"]

    comment = {
        "task_id": task_id,
        "content": content,
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
    }

    result = collection.insert_one(comment)
    comment["id"] = str(result.inserted_id)
    return comment


def get_comment(comment_id: str) -> Optional[Dict]:
    """Retrieve a single comment by ID."""
    collection = current_app.extensions["comments_collection"]
    comment = collection.find_one({"_id": ObjectId(comment_id)})
    if comment:
        comment["id"] = str(comment["_id"])
    return comment


def update_comment(comment_id: str, content: str) -> Optional[Dict]:
    """Update comment content."""
    collection = current_app.extensions["comments_collection"]
    update = {
        "$set": {
            "content": content,
            "updated_at": datetime.utcnow().isoformat()
        }
    }

    result = collection.update_one({"_id": ObjectId(comment_id)}, update)
    if result.modified_count:
        return get_comment(comment_id)
    return None


def delete_comment(comment_id: str) -> bool:
    """Delete a comment."""
    collection = current_app.extensions["comments_collection"]
    result = collection.delete_one({"_id": ObjectId(comment_id)})
    return result.deleted_count > 0


def list_comments(task_id: int) -> List[Dict]:
    """List comments filtered by task_id."""
    collection = current_app.extensions["comments_collection"]
    cursor = collection.find({"task_id": task_id})
    comments = []
    for c in cursor:
        c["id"] = str(c["_id"])
        comments.append(c)
    return comments
