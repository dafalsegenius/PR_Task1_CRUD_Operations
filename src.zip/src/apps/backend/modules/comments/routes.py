from flask import Blueprint, request, jsonify, current_app
from .models import (
    create_comment,
    get_comment,
    update_comment,
    delete_comment,
    list_comments,
)

comments_bp = Blueprint("comments", __name__, url_prefix="/api/comments")

def success_response(data, status=200):
    return jsonify({"success": True, "data": data}), status

def error_response(message, status=400):
    return jsonify({"success": False, "error": message}), status

@comments_bp.route("/", methods=["POST"])
def add_comment():
    data = request.get_json() or {}

    task_id = data.get("task_id")
    content = data.get("content")

    if task_id is None or not content:
        return error_response("Both 'task_id' and 'content' are required.", 400)

    comment = create_comment(int(task_id), content)
    return success_response(comment, 201)

@comments_bp.route("/task/<int:task_id>", methods=["GET"])
def get_comments_for_task(task_id):
    comments = list_comments(task_id)
    return success_response(comments)

@comments_bp.route("/comment/<comment_id>", methods=["GET"])
def get_comment_by_id(comment_id):
    comment = get_comment(comment_id)
    if not comment:
        return error_response("Comment not found.", 404)
    return success_response(comment)

@comments_bp.route("/comment/<comment_id>", methods=["PUT"])
def edit_comment(comment_id):
    data = request.get_json() or {}
    content = data.get("content")
    if not content:
        return error_response("'content' field is required.", 400)

    comment = update_comment(comment_id, content)
    if not comment:
        return error_response("Comment not found for update.", 404)

    return success_response(comment)

@comments_bp.route("/comment/<comment_id>", methods=["DELETE"])
def remove_comment(comment_id):
    success = delete_comment(comment_id)
    if not success:
        return error_response("Comment not found for deletion.", 404)
    return success_response({"deleted": True})
