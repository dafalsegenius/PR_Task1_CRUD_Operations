from flask import Blueprint, request, jsonify
from modules.authentication.rest_api.authentication_service import AuthenticationService

auth_bridge_bp = Blueprint("auth_bridge", __name__, url_prefix="/api")

# SIGNUP  → matches frontend signup()
@auth_bridge_bp.route("/accounts", methods=["POST"])
def create_account():
    data = request.get_json()

    if not data:
        return jsonify({"success": False, "error": "No data provided"}), 400

    first = data.get("first_name")
    last = data.get("last_name")
    username = data.get("username")
    password = data.get("password")

    if not (first and last and username and password):
        return jsonify({"success": False, "error": "Missing fields"}), 400

    try:
        AuthenticationService.signup(first, last, username, password)
        return jsonify({"success": True, "data": "Account created"}), 201
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


# LOGIN → matches frontend login()
@auth_bridge_bp.route("/access-tokens", methods=["POST"])
def create_access_token():
    data = request.get_json() or {}

    username = data.get("username")
    password = data.get("password")

    if not (username and password):
        return jsonify({"success": False, "error": "Username and password required"}), 400

    try:
        token = AuthenticationService.login(username, password)
        return jsonify(token), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 401
